import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
// import { BrowserRouter, Routes, Route } from "react-router-dom";
ReactDOM.render(

    <App />

  ,
  
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();


// const redux = require('redux')
// const createStore = redux.createStore
// const applyMiddelware = redux.applyMiddleware
// const BUY_CAKE = 'BUY_CAKE'


// function buyCake(){
//     return {
//         type: BUY_CAKE
//     }
// }

// const initialState = {
//     numberOfCake:10
// }

// const reducer = (state = initialState, action)=>{
//     switch(action.type){
//         case BUY_CAKE: return {
//             ...state,
//             numberOfCake : state.numberOfCake - 1
//         }
//         default: return state
//     }
// }

// const store = createStore(reducer,applyMiddelware)
// console.log('initial state', store.getState() )
// const unsubscribe = store.subscribe(()=> console.log('updated state',store.getState()))
// store.dispatch(buyCake())
// store.dispatch(buyCake())
// store.dispatch(buyCake())
// unsubscribe()


