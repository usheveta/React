import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { buyCake } from '../Redux/Cakes/cakeAction';

const CakeHook = () =>{
    const noOfcake = useSelector(state=>state.numOfCakes)
    const buyCake = useDispatch()
    
    return <hi>No of cakes {noOfcake}</hi>
}

export default CakeHook;