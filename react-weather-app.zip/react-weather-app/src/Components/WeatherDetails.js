import axios from "axios";
import React, { useEffect, useState } from "react";

const WeatherDetails = ({country}) =>{
    let [weather,setWeather] = useState("")
    let [humidity,setHumidity] = useState("")
    let [temperature,setTemperature] = useState("");
    let [loading,setLoading] = useState(false)
    
    useEffect(()=>{
        setLoading(true)
        axios.get(`http://api.openweathermap.org/data/2.5/weather?q=${country}&appid=095609ab28fb3c45d53f0772055c48e5`)
        .then((ele)=>{
            let tempWeather = ele.data.weather[0].description;
            let tempHumidity = ele.data.main.humidity;
            let tempTemperature = ele.data.main.temp
            setWeather(tempWeather);
            setHumidity(`${tempHumidity}%`);
            setTemperature(Math.floor(parseInt(tempTemperature)- 273.15)) ;
            
        }).catch((err)=> console.log(err))
        setLoading(false)
    })
    return(
        <div className="myStyle">
            <h3 style={{marginTop : "64px"}}>{country}</h3>
            {!loading?<table>
                <thead>
                <tr>
                    <th>Cloud</th>
                    <th>Humidity</th>
                    <th>Temperature <sup>°</sup>C</th>
                </tr>
                </thead>
                
                <tbody>
                    <tr><td>{weather.toLocaleUpperCase()}</td><td>{humidity}</td><td>{temperature}</td></tr>

                </tbody>
               
            </table>: <div>Loaidng</div>}
            
        </div>
    )
}

export default WeatherDetails;