import React from "react";
import WeatherDetails from "./WeatherDetails";

class CheckWeather extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            country : "",

        }
        
    }
    onchangeHandler=(e)=>{
        this.setState({country:e.target.value},()=> console.log(this.state.country));

    }
    render(){
        return(
            <div>
                <div id="weatherhome">
                    <h3>WELCOME TO WEATHER REPORT</h3>
                </div>
                <h3>Select country</h3>
                <select onChange={this.onchangeHandler} placeholder="Select City">
                    <option value={""}>Select</option>
                    <option value={"London"}>London</option>
                    <option value={"Kolkata"}>Kolkata</option>
                    <option value={"Delhi"}>Delhi</option>
                    <option value={"Patna"}>Patna</option>
                    <option value={"Pune"}>Pune</option>
                    <option value={"Chandigarh"}>Chandigarh</option>
                </select>
                {this.state.country?<WeatherDetails country={this.state.country}/>:null}
        </div>
            

        )
    }

}

export default CheckWeather;