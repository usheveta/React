import React from "react";
import axios from 'axios';
import ReactTable from 'react-table'
class TestData extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            comments :[]
            
        }

    }
    componentDidMount(){
        
    }

    clickHandler = () =>{
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((response)=> this.setState({comments:response.data}))
        .catch((error)=>console.log(error))
    }
    
    render(){
        
        let {comments} = this.state
        return(
            <div>
                <button onClick={this.clickHandler}>Click to load</button>
                {comments.length?<ul>{comments.map((ele)=><li key={ele.name}>{ele.name}</li>)}</ul>:null}

            </div>

            
            
        )
    }
}

export default TestData;