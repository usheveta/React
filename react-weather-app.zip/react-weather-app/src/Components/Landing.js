import React from "react";
import { NavLink} from 'react-router-dom'

class Landing extends React.Component{
    constructor(props){
        super(props);
        this.state={

        }
    }

    render(){
        return(
            <nav>
                <NavLink to="/testdata">Test Data</NavLink>
                <NavLink to="/testdataperformance">Test Data Performance</NavLink>
            </nav>
        )
    }
}

export default Landing;