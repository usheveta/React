import React from "react";

const TestDataPerformance = (props) =>{
    return (<div>In Test data performance</div>)
}

export default TestDataPerformance;