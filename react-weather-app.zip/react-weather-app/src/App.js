import logo from './logo.svg';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import Landing from './Components/Landing';
import TestData from './Components/TestData';
import TestDataPerformance from './Components/TestDataPerformance';
import CheckWeather from './Components/CheckWeater';

function App() {
  return (
    <div className="App">
    {/* <Landing/>
    <Routes>
      
      <Route path="testdata" element={<TestData/>}/>
      <Route path="testdataperformance" element={<TestDataPerformance/>}/>
    </Routes></div> */}
    <CheckWeather/>
    </div>
  );
}

export default App;
