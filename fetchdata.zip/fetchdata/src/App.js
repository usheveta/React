import {Routes,Route} from 'react-router-dom';
import './App.css';
import {Home} from './components/Home';
import {DataView} from './components/DataView.js';
import { NavBar } from './components/NavBar';
import { LoadTime } from './components/LoadTime';

function App() {
  return (
    <>
    <NavBar />
    <Routes>
      <Route path ='/' element = {<Home />}></Route>
      <Route path ='dataview' element = {<DataView />}></Route>
      <Route path ='loadtime' element = {<LoadTime />}></Route>
    </Routes>
    </>
    
  );
}

export default App;
