import React from 'react'
import { NavLink } from 'react-router-dom';

export const NavBar = () => {
    return (
        <nav>
        <NavLink to ='/'>Home</NavLink>
        <NavLink to ='/dataview'>Dataview</NavLink>
        <NavLink to ='/loadtime'>LoadTime</NavLink> 
    </nav>
    )
}
