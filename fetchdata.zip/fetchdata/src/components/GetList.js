import React, { Component } from 'react'
import axios from 'axios'

class GetList extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             lists: [],
             errorMessage: ''
        }
    }
    componentDidMount() {
        axios.get('https://jsonplaceholder.typicode.com/posts')
        .then(response =>{
            console.log(response);
            this.setState({lists :response.data})
        })
        .catch(error =>{
            console.log(error);
            this.setState({errorMessage:'Error retreiving data'})
        })
    }
    
    render() {
        const {lists, errorMessage} = this.state;
        return (
            <div>
                Get Lists
                {
                    lists.length ?
                    lists.map(list => 
                        <div key ={list.id}>{list.title} </div>
                    ) : null
                }
                {errorMessage ? <div>{errorMessage}</div> : null}
            </div>
        )
    }
}

export default GetList
