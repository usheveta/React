import React from 'react'

export const LoadTime = () => {
    return (
        <div>
            Load Time
        </div>
    )
}
